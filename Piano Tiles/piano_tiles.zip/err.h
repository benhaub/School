#ifndef __ERR_H__
#define __ERR_H_

#include "includes.h"

void checkFlagPend(INT8U);
void checkFlagPost(INT8U);
void checkFlagAccept(INT8U);

#endif /*__ERR_H__*/
