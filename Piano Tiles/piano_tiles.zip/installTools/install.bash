#! /bin/bash

###############################################################################
# Authour   : Ben Haubrich                                                    #
# File      : run.bash                                                        #
# Synopsis  : Install piano tiles by making two directories called src and bsp#
#             All the .c, .h and .bash are moved to src. The directory is     #
#             changed to bsp and the bsp is generated. Then directory is      #
#             changed to src and a makefile is generated. Then directory is   #
#             changed back to bsp and make is run.                            #
###############################################################################

mkdir ../src
mkdir ../bsp
yes | unzip ../piano_tiles.zip -d ..
cd ../bsp
nios2-bsp-editor
cd ..
mv *.c *.h *.bash src
cd src
nios2-app-generate-makefile --bsp-dir ../bsp --src-dir . --elf-name piano_game.elf
cd ../bsp
make
cd ../src
make
chmod u+x *bash
