#!/bin/bash

###############################################################
#Authour  :  Ben Haubrich                                     #
#File     :  nios2_command_shell.sh                           #
#Synopsis :  simple shortcut to start the nios2_command_shell #
###############################################################

#NOTE: You may need to permission to execute this script. If you try and get
# "permission denied", try the following command;
#$ chmod u+x nios2_command_shell.sh

sh /opt/intelFPGA/18.1/nios2eds/nios2_command_shell.sh

